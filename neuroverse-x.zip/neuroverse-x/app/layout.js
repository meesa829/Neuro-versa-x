import { SpeedInsights } from "@vercel/speed-insights/next";
import { Analytics } from "@vercel/analytics/react";

export const metadata = {
  title: "NeuroVerse X — AI TikTok Creator Platform",
  description: "Go viral with AI-powered captions, hashtags, hooks and real-time analytics.",
  keywords: "TikTok, AI, viral, creator, captions, hashtags",
  openGraph: {
    title: "NeuroVerse X",
    description: "AI-Powered TikTok Growth Platform",
    type: "website",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body style={{ margin: 0, padding: 0 }}>
        {children}
        <SpeedInsights />
        <Analytics />
      </body>
    </html>
  );
}
