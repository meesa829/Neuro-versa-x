"use client";
import NeuroVerseX from "../components/NeuroVerseX";

export default function Home() {
  return <NeuroVerseX />;
}
